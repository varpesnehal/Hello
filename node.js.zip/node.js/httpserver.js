var http=require("http");
var dbmodule = require('./authenticate'); 
var url=require("url");
var querystring= require("querystring");
var module=require("./authenticate");
function onRequest(request, response) { 
 var query=url.parse(request.url).query;                                             
 var name=querystring.parse(query)["uname"];
 var pwd=querystring.parse(query)["password"];
 result=dbmodule.authenticateUser(name,pwd);
 response.writeHead(200,{"Content-Type":"text/html"});
 
 response.end("<html><body><h1>"+name+' '+result+" "+pwd+"</h1></body></html>"); 
 console.log("Request received"); 
  }
  http.createServer(onRequest).listen(3000); 
console.log("Server Started. Try to access using the browser");